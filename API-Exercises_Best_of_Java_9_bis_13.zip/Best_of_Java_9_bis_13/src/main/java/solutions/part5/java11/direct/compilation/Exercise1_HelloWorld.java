package solutions.part5.java11.direct.compilation;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise1_HelloWorld 
{
	public static void main(String... args) 
	{
		System.out.println("Hello Execute After Compile");
		
		var procesInfo = ProcessHandle.current().info();
		System.out.println(procesInfo);
    }
}