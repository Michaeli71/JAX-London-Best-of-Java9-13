package exercises.part6.java12_13;

import java.io.IOException;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise5_Teeing 
{
	public static void main(String[] args) throws IOException 
	{
		// In einem Durchlauf Minimum und Maximm finden
		Stream<String> values = Stream.of("CCC", "BB", "A", "DDDD");
		
		// TODO
		//List<Optional<String>> optMinMax = values.collect(teeing(
				    
		//System.out.println(optMinMax); 
	}
}
