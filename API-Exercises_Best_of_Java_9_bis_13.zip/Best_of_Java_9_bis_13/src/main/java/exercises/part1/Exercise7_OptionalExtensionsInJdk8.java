package exercises.part1;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise7_OptionalExtensionsInJdk8
{
	public static <T> void ifPresentOrElse(final Optional<T> optional, final Consumer<? super T> action, final Runnable elseAction) 
	{
		// TODO
	}

	public static <T> Optional<T> or(Optional<T> first, Supplier<? extends Optional<? extends T>> supplier) 
	{		
		// TODO
		return first;
	}

	public static <T> Optional<T> or(Optional<T> first, Supplier<? extends Optional<? extends T>>... suppliers) 
	{
		// TODO
		return first;
	}
	
	// Zum Test
	
	public static void main(final String[] args) 
	{
        Optional<Long> optValue1 = or(calc1(), () -> calc2(), () -> calc3());
        Optional<Long> optValue2 = or(calc1e(), () -> calc2(), () -> calc3());
        Optional<Long> optValue3 = or(calc1e(), () -> calc2e(), () -> calc3());
        Optional<Long> optValue4 = or(calc1e(), () -> calc2e(), () -> calc3e());

        /* Expected
        Optional[1]
        Optional[2]
        Optional[3]
        Optional.empty
        */
        System.out.println(optValue1);
        System.out.println(optValue2);
        System.out.println(optValue3);
        System.out.println(optValue4);
    }

    static Optional<Long> calc1() 
    {
        return Optional.of(1L);
    }

    static Optional<Long> calc1e() 
    {
        return Optional.empty();
    }

    static Optional<Long> calc2() 
    {
        return Optional.of(2L);
    }

    static Optional<Long> calc2e() 
    {
        return Optional.empty();
    }

    static Optional<Long> calc3() 
    {
        return Optional.of(3L);
    }

    static Optional<Long> calc3e() 
    {
        return Optional.empty();
    }
}
