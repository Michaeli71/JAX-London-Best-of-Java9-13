package exercises.part4.java10;

import java.util.Optional;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise3_Optional {

	public static void main(String[] args) 
	{
		final Optional<String> optName = Optional.of("Michael");
		final String result = badStyleExtractValue(optName);
		System.out.println(result);
		
		final Optional<String> optEmpty = Optional.empty();
		final String result2 = badStyleExtractValue(optEmpty);
		System.out.println(result2);
	}

	static <T> T badStyleExtractValue(final Optional<T> opt)
	{
		T value = opt.get();
		return value;
	}
}
