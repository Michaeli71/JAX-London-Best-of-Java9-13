package exercises.part4.java10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise2c_UnmodifiableCollections 
{
	public static void main(String[] args) 
	{
		final List<String> names = List.of("Tim", "Tom", "Mike");
		
		// 3 Varianten Kopien von unmodifizierbaren Listen zu erzeugen
		final List<String> copy1 = new ArrayList<>(names);
		final List<String> copy2 = List.copyOf(names);
		final List<String> wrapper = Collections.unmodifiableList(names);
		
		// TODO
	}

	private static void tryModification(final String info, final List<String> list) 
	{
		try
		{
			list.set(1, "XXX");
			System.out.println(info + ": " + list);
		}
		catch (java.lang.UnsupportedOperationException ex)
		{
			System.out.println(info + ": set() not allowed");
		}
	}
}
