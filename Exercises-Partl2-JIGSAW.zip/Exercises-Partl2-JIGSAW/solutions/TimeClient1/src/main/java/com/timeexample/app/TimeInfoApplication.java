package com.timeexample.app;

import com.timeexample.services.TimeUtils;

public class TimeInfoApplication 
{
	public static void main(final String[] args)
	{
		System.out.println("Now: " + TimeUtils.getCurrentTime());
	}
}
