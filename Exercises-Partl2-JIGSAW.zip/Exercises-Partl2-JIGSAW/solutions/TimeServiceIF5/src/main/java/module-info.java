module timeservice {
	exports com.timeexample.spi;	
}