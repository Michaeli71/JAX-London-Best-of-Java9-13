package com.timeexample.app;

import java.util.Iterator;
import java.util.Optional;
import java.util.ServiceLoader;

import com.google.common.base.Joiner;
import com.timeexample.spi.TimeService;

public class TimeInfoApplication 
{
	public static void main(final String[] args)
	{	
		final Optional<TimeService> optService = lookup(TimeService.class);
		optService.ifPresentOrElse(service ->
		{
			System.out.println("Service: " + service.getClass());
			System.out.println("Now: " + service.getCurrentTime());
		},
		() -> System.err.println("No service provider found!"));
		
		final Joiner joiner = Joiner.on(", " ).skipNulls();
		System.out.println(joiner.join("Guava", null, "From", "ModulePath"));
	}
	
	private static <T> Optional<T> lookup(final Class<T> clazz) 
	{
		final Iterator<T> iterator = ServiceLoader.load(clazz).iterator();
		if (iterator.hasNext()) 
		{
			return Optional.of(iterator.next()); 
		}
		return Optional.empty(); 
	}
}